# NoStab Cam

A minimal Android video recorder with electronic stabilisation always off, so the
frame is not cropped. It lists every camera the phone exposes (including hidden ids
and the physical lenses behind the multi-camera) so the ultrawide can be reached.

## Get the APK (no Android Studio needed)

1. Create a new empty GitHub repository.
2. Upload everything in this folder to it, including the hidden `.github` folder
   (`git add -A && git commit -m "NoStab Cam" && git push`, or drag the files in
   on github.com).
3. Open the repo's **Actions** tab and wait for "Build APK" to finish (about 3 minutes).
4. Open **Releases**, download `NoStabCam.apk` on the phone and install it.

Or open the folder in Android Studio and press Run.

## Controls

| Control | What it does |
| --- | --- |
| Flash icon (top left) | Torch on / off, on lenses that have a flash. |
| Arrow (top centre) | Menu: lens correction, the full camera list, camera info. |
| `1080 · 30` (top right) | Tap the size or the frame rate to change it. 4:3 sizes use the full sensor. |
| `±` | Exposure slider. |
| `0.6  1x  5` | Switch lens. If one route to a lens fails, the app tries the next one by itself. |
| Gallery thumbnail | Opens the last video or photo. |
| Red button | Record / stop. |
| Small white circle | Take a photo, also while recording. |
| Flip icon | Front / back camera. |

Electronic and optical stabilisation are always off. After 1 minute of recording
without a touch the screen goes black and dim, showing only the timer; recording
continues. Tap anywhere to wake it.

Videos are saved to `Movies/NoStabCam`, photos to `Pictures/NoStabCam`.
