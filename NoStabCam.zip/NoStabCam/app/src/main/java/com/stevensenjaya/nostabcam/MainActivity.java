package com.stevensenjaya.nostabcam;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Rational;
import android.util.Size;
import android.util.SizeF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * NoStab Cam: a video recorder with electronic stabilisation always off (no crop),
 * every lens reachable (including the ultrawide), a dark screen while recording,
 * and photo snapshots. Layout follows the Xiaomi camera.
 */
public class MainActivity extends Activity implements TextureView.SurfaceTextureListener {

    private static final int YELLOW = 0xFFF5C542;
    private static final int RED = 0xFFE5383B;
    private static final long DARK_AFTER_MS = 60_000;
    private static final int REQ_PERMS = 1;

    /** One way of opening one lens. */
    private static class Lens {
        String openId;          // id passed to openCamera()
        String physId;          // physical lens streamed through a logical camera, or null
        String route;           // listed / hidden / via N
        int priority;
        String label;
        int facing;
        boolean logical;
        float equiv;            // 35mm-equivalent focal length
        CameraCharacteristics chars;      // the lens producing the image
        CameraCharacteristics openChars;  // the camera that is opened
    }

    /** One physical lens, with every route that reaches it (tried in order). */
    private static class Group {
        final List<Lens> routes = new ArrayList<>();
        int facing;
        float equiv;
        int idx;
        int good = -1;
        String label = "1";
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private CameraManager manager;
    private final List<Lens> lenses = new ArrayList<>();
    private final List<Group> groups = new ArrayList<>();
    private final StringBuilder report = new StringBuilder();
    private Lens cur;
    private Group curGroup;

    private CameraDevice device;
    private CameraCaptureSession session;
    private CaptureRequest.Builder request;
    private Surface previewSurface;
    private ImageReader jpegReader;
    private final Set<String> jpegBad = new HashSet<>();
    private boolean opening, resumed, pendingStart, frameSeen;

    private List<Size> sizes = new ArrayList<>();
    private Size videoSize = new Size(1920, 1080);
    private List<Integer> fpsOptions = new ArrayList<>();
    private int fps = 30;
    private List<Float> zoomSteps = new ArrayList<>();
    private float zoom = 1f;
    private boolean lensFix = true;
    private boolean torch;
    private Range<Integer> evRange;
    private Rational evStep;
    private int ev;

    private MediaRecorder recorder;
    private ParcelFileDescriptor outFd;
    private Uri outUri;
    private boolean recording, starting;
    private long recStart;
    private int deviceOrientation;
    private OrientationEventListener orientationListener;

    private boolean dark, swallowTouch;

    private Uri lastUri;
    private String lastMime;

    // views
    private FrameLayout root, frameBox, darkOverlay;
    private TextureView texture;
    private View flashView;
    private ImageView flashBtn, chevronBtn, flipBtn, thumb;
    private TextView resText, fpsText, topTimer, darkTimer, evBtn, evText;
    private LinearLayout pillRow, evRow;
    private SeekBar evBar;
    private FrameLayout recBtn;
    private View recInner, snapBtn;
    private final List<View> rotatables = new ArrayList<>();

    // ================================================================== lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        SharedPreferences p = getSharedPreferences("app", MODE_PRIVATE);
        String u = p.getString("lastUri", null);
        if (u != null) {
            lastUri = Uri.parse(u);
            lastMime = p.getString("lastMime", "video/mp4");
        }

        buildUi();
        loadThumb();

        orientationListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int o) {
                if (o == ORIENTATION_UNKNOWN) return;
                int snapped = ((o + 45) / 90 * 90) % 360;
                if (snapped != deviceOrientation) {
                    deviceOrientation = snapped;
                    rotateUi(true);
                }
            }
        };

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO}, REQ_PERMS);
        } else {
            initCameras();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (code != REQ_PERMS) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            initCameras();
            tryOpen();
        } else {
            toast("Camera permission is needed to record.");
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        orientationListener.enable();
        tryOpen();
    }

    @Override
    protected void onPause() {
        resumed = false;
        orientationListener.disable();
        if (recording || starting) stopRecording(false);
        setDark(false);
        closeCamera();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }

    // ================================================================== dark screen

    private final Runnable goDark = () -> {
        if (recording) setDark(true);
    };

    private void scheduleDark() {
        ui.removeCallbacks(goDark);
        if (recording) ui.postDelayed(goDark, DARK_AFTER_MS);
    }

    private void setDark(boolean on) {
        dark = on;
        darkOverlay.setVisibility(on ? View.VISIBLE : View.GONE);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = on ? 0.01f : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        getWindow().setAttributes(lp);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (dark && a == MotionEvent.ACTION_DOWN) {
            setDark(false);
            scheduleDark();
            swallowTouch = true;
            return true;
        }
        if (swallowTouch) {
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) swallowTouch = false;
            return true;
        }
        if (recording && a == MotionEvent.ACTION_DOWN) scheduleDark();
        return super.dispatchTouchEvent(e);
    }

    // ================================================================== UI

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    private static GradientDrawable oval(int fill, int strokeW, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(fill);
        if (strokeW > 0) d.setStroke(strokeW, stroke);
        return d;
    }

    private ImageView icon(int res, int sizeDp, View.OnClickListener l) {
        ImageView v = new ImageView(this);
        v.setImageResource(res);
        v.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        v.setPadding(dp(8), dp(8), dp(8), dp(8));
        v.setOnClickListener(l);
        v.setLayoutParams(new FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return v;
    }

    private static FrameLayout.LayoutParams flp(int w, int h, int gravity) {
        return new FrameLayout.LayoutParams(w, h, gravity);
    }

    private void buildUi() {
        final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
        final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        // ---- preview frame (sized in restartPreview)
        frameBox = new FrameLayout(this);
        texture = new TextureView(this);
        texture.setSurfaceTextureListener(this);
        frameBox.addView(texture, flp(MATCH, MATCH, Gravity.CENTER));
        frameBox.addView(new Corners(this, getResources().getDisplayMetrics().density),
                flp(MATCH, MATCH, Gravity.CENTER));
        flashView = new View(this);
        flashView.setBackgroundColor(Color.WHITE);
        flashView.setAlpha(0f);
        frameBox.addView(flashView, flp(MATCH, MATCH, Gravity.CENTER));
        FrameLayout.LayoutParams fb = flp(MATCH, MATCH, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        fb.topMargin = dp(72);
        root.addView(frameBox, fb);

        // ---- top bar
        FrameLayout top = new FrameLayout(this);
        top.setBackgroundColor(Color.BLACK);
        root.addView(top, flp(MATCH, dp(72), Gravity.TOP));

        flashBtn = icon(R.drawable.ic_flash_off, 48, v -> {
            if (!flashAvailable()) {
                toast("This lens has no flash.");
                return;
            }
            torch = !torch;
            refreshLabels();
            pushRequest();
        });
        FrameLayout.LayoutParams fl = flp(dp(48), dp(48), Gravity.START | Gravity.CENTER_VERTICAL);
        fl.leftMargin = dp(16);
        top.addView(flashBtn, fl);
        rotatables.add(flashBtn);

        chevronBtn = icon(R.drawable.ic_chevron, 0, v -> showMenu());
        chevronBtn.setBackground(roundRect(0xFF2A2A2A, dp(16)));
        top.addView(chevronBtn, flp(dp(56), dp(34), Gravity.CENTER));

        topTimer = new TextView(this);
        topTimer.setTextColor(Color.WHITE);
        topTimer.setTextSize(16);
        topTimer.setTypeface(Typeface.MONOSPACE);
        topTimer.setPadding(dp(12), dp(4), dp(12), dp(4));
        topTimer.setBackground(roundRect(RED, dp(14)));
        topTimer.setVisibility(View.GONE);
        top.addView(topTimer, flp(WRAP, WRAP, Gravity.CENTER));

        LinearLayout rf = new LinearLayout(this);
        rf.setOrientation(LinearLayout.HORIZONTAL);
        rf.setGravity(Gravity.CENTER_VERTICAL);
        resText = topText(v -> pickSize());
        TextView dot = new TextView(this);
        dot.setText(" · ");
        dot.setTextColor(Color.WHITE);
        dot.setTextSize(20);
        fpsText = topText(v -> pickFps());
        rf.addView(resText);
        rf.addView(dot);
        rf.addView(fpsText);
        FrameLayout.LayoutParams rl = flp(WRAP, WRAP, Gravity.END | Gravity.CENTER_VERTICAL);
        rl.rightMargin = dp(20);
        top.addView(rf, rl);

        // ---- bottom panel
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER_HORIZONTAL);
        bottom.setPadding(0, 0, 0, dp(20));

        // exposure slider (hidden until ± is tapped)
        evRow = new LinearLayout(this);
        evRow.setOrientation(LinearLayout.HORIZONTAL);
        evRow.setGravity(Gravity.CENTER_VERTICAL);
        evRow.setPadding(dp(16), dp(4), dp(16), dp(4));
        evRow.setBackground(roundRect(0x99000000, dp(18)));
        evText = new TextView(this);
        evText.setTextColor(YELLOW);
        evText.setTextSize(13);
        evText.setMinWidth(dp(44));
        evBar = new SeekBar(this);
        evBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                if (!fromUser || evRange == null) return;
                ev = progress + evRange.getLower();
                refreshLabels();
                pushRequest();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        evRow.addView(evText);
        evRow.addView(evBar, new LinearLayout.LayoutParams(dp(230), WRAP));
        evRow.setVisibility(View.GONE);
        LinearLayout.LayoutParams erl = new LinearLayout.LayoutParams(WRAP, WRAP);
        erl.bottomMargin = dp(8);
        bottom.addView(evRow, erl);

        // zoom / lens row
        FrameLayout zoomRow = new FrameLayout(this);
        evBtn = new TextView(this);
        evBtn.setText("±");
        evBtn.setTextColor(Color.WHITE);
        evBtn.setTextSize(18);
        evBtn.setGravity(Gravity.CENTER);
        evBtn.setBackground(oval(Color.TRANSPARENT, dp(2), Color.WHITE));
        evBtn.setOnClickListener(v ->
                evRow.setVisibility(evRow.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        FrameLayout.LayoutParams el = flp(dp(32), dp(32), Gravity.START | Gravity.CENTER_VERTICAL);
        el.leftMargin = dp(30);
        zoomRow.addView(evBtn, el);
        rotatables.add(evBtn);
        pillRow = new LinearLayout(this);
        pillRow.setOrientation(LinearLayout.HORIZONTAL);
        pillRow.setGravity(Gravity.CENTER);
        zoomRow.addView(pillRow, flp(WRAP, WRAP, Gravity.CENTER));
        bottom.addView(zoomRow, new LinearLayout.LayoutParams(MATCH, dp(56)));

        // mode row
        View handle = new View(this);
        handle.setBackground(roundRect(0xFF8A8A8A, dp(2)));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(dp(24), dp(3));
        hl.topMargin = dp(6);
        bottom.addView(handle, hl);
        TextView mode = new TextView(this);
        mode.setText("Video");
        mode.setTextColor(YELLOW);
        mode.setTextSize(17);
        mode.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(WRAP, WRAP);
        ml.topMargin = dp(8);
        ml.bottomMargin = dp(14);
        bottom.addView(mode, ml);

        // controls row: [gallery][ ][record][snapshot][flip]
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);

        thumb = new ImageView(this);
        thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumb.setBackground(roundRect(0xFF222222, dp(8)));
        thumb.setClipToOutline(true);
        thumb.setOnClickListener(v -> openLast());
        controls.addView(cell(thumb, dp(52), 1f));
        rotatables.add(thumb);

        controls.addView(cell(new View(this), 0, 1f));

        recBtn = new FrameLayout(this);
        View ring = new View(this);
        ring.setBackground(oval(Color.TRANSPARENT, dp(4), Color.WHITE));
        recBtn.addView(ring, flp(dp(78), dp(78), Gravity.CENTER));
        recInner = new View(this);
        recBtn.addView(recInner, flp(dp(62), dp(62), Gravity.CENTER));
        recBtn.setOnClickListener(v -> {
            if (recording) stopRecording(true);
            else startRecording();
        });
        controls.addView(cell(recBtn, dp(78), 1.3f));

        snapBtn = new View(this);
        snapBtn.setBackground(oval(0xFFEDEDED, dp(3), 0xFF9A9A9A));
        snapBtn.setOnClickListener(v -> takeSnapshot());
        controls.addView(cell(snapBtn, dp(44), 1f));

        flipBtn = icon(R.drawable.ic_flip, 0, v -> flipCamera());
        flipBtn.setPadding(dp(4), dp(4), dp(4), dp(4));
        controls.addView(cell(flipBtn, dp(48), 1f));
        rotatables.add(flipBtn);

        bottom.addView(controls, new LinearLayout.LayoutParams(MATCH, dp(96)));
        root.addView(bottom, flp(MATCH, WRAP, Gravity.BOTTOM));

        // ---- dark overlay (shown after a minute of recording)
        darkOverlay = new FrameLayout(this);
        darkOverlay.setBackgroundColor(Color.BLACK);
        LinearLayout dk = new LinearLayout(this);
        dk.setOrientation(LinearLayout.VERTICAL);
        dk.setGravity(Gravity.CENTER_HORIZONTAL);
        darkTimer = new TextView(this);
        darkTimer.setTextColor(0xFFB0B0B0);
        darkTimer.setTextSize(44);
        darkTimer.setTypeface(Typeface.MONOSPACE);
        dk.addView(darkTimer);
        TextView hint = new TextView(this);
        hint.setText("Still recording · tap to wake");
        hint.setTextColor(0xFF666666);
        hint.setTextSize(14);
        LinearLayout.LayoutParams hl2 = new LinearLayout.LayoutParams(WRAP, WRAP);
        hl2.topMargin = dp(8);
        dk.addView(hint, hl2);
        darkOverlay.addView(dk, flp(WRAP, WRAP, Gravity.CENTER));
        darkOverlay.setVisibility(View.GONE);
        rotatables.add(dk);
        root.addView(darkOverlay, flp(MATCH, MATCH, Gravity.CENTER));

        setContentView(root);
        setRecButton(false);
        refreshLabels();
    }

    private TextView topText(View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(22);
        t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
        t.setPadding(dp(4), dp(8), dp(4), dp(8));
        t.setOnClickListener(l);
        rotatables.add(t);
        return t;
    }

    private static GradientDrawable roundRect(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private View cell(View child, int size, float weight) {
        FrameLayout c = new FrameLayout(this);
        if (size > 0) c.addView(child, flp(size, size, Gravity.CENTER));
        c.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight));
        return c;
    }

    private void setRecButton(boolean rec) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(RED);
        if (rec) {
            d.setShape(GradientDrawable.RECTANGLE);
            d.setCornerRadius(dp(8));
            recInner.setLayoutParams(flp(dp(30), dp(30), Gravity.CENTER));
        } else {
            d.setShape(GradientDrawable.OVAL);
            recInner.setLayoutParams(flp(dp(62), dp(62), Gravity.CENTER));
        }
        recInner.setBackground(d);
    }

    private void rotateUi(boolean animate) {
        float target = -deviceOrientation;
        for (View v : rotatables) {
            float now = v.getRotation();
            float delta = (((target - now) % 360) + 540) % 360 - 180;
            if (animate) v.animate().rotation(now + delta).setDuration(200).start();
            else v.setRotation(now + delta);
        }
    }

    private static String resLabel(Size s) {
        boolean wide = Math.abs((float) s.getWidth() / s.getHeight() - 16f / 9f) < 0.02f;
        String h = s.getHeight() >= 2160 ? "4K" : String.valueOf(s.getHeight());
        return wide ? h : h + " 4:3";
    }

    private boolean flashAvailable() {
        if (cur == null) return false;
        Boolean b = cur.openChars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
        return b != null && b;
    }

    private void refreshLabels() {
        boolean idle = !recording && !starting;
        resText.setText(resLabel(videoSize));
        fpsText.setText(String.valueOf(fps));
        resText.setEnabled(idle);
        fpsText.setEnabled(idle);
        resText.setAlpha(idle ? 1f : 0.5f);
        fpsText.setAlpha(idle ? 1f : 0.5f);

        boolean on = torch && flashAvailable();
        flashBtn.setImageResource(on ? R.drawable.ic_flash_on : R.drawable.ic_flash_off);
        flashBtn.setColorFilter(on ? YELLOW : Color.WHITE);
        flashBtn.setAlpha(flashAvailable() ? 1f : 0.35f);

        chevronBtn.setVisibility(recording ? View.GONE : View.VISIBLE);
        topTimer.setVisibility(recording ? View.VISIBLE : View.GONE);
        thumb.setVisibility(idle ? View.VISIBLE : View.INVISIBLE);
        flipBtn.setVisibility(idle ? View.VISIBLE : View.INVISIBLE);

        boolean hasEv = evRange != null && evRange.getUpper() > evRange.getLower();
        evBtn.setVisibility(hasEv ? View.VISIBLE : View.INVISIBLE);
        if (!hasEv) evRow.setVisibility(View.GONE);
        if (hasEv) {
            evBar.setMax(evRange.getUpper() - evRange.getLower());
            evBar.setProgress(ev - evRange.getLower());
            float val = evStep == null ? ev : ev * evStep.floatValue();
            evText.setText(String.format(Locale.US, "%+.1f", val));
            evBtn.setTextColor(ev != 0 ? YELLOW : Color.WHITE);
            evBtn.setBackground(oval(Color.TRANSPARENT, dp(2), ev != 0 ? YELLOW : Color.WHITE));
        }
        rebuildZoomRow();
    }

    private static String fmt1(float f) {
        String s = String.format(Locale.US, "%.1f", f);
        return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
    }

    private static String ratioLabel(float r) {
        if (r < 0.95f) return fmt1(r);
        float rr = Math.round(r);
        if (Math.abs(r - rr) < 0.2f) return String.valueOf((int) rr);
        return fmt1(r);
    }

    private void rebuildZoomRow() {
        pillRow.removeAllViews();
        if (cur == null) return;
        boolean idle = !recording && !starting;
        if (cur.logical && zoomSteps.size() > 1) {
            for (final float z : zoomSteps) {
                boolean sel = Math.abs(z - zoom) < 0.005f;
                addPill(ratioLabel(z), sel, true, v -> {
                    zoom = z;
                    refreshLabels();
                    pushRequest();
                });
            }
            return;
        }
        for (final Group g : groups) {
            if (g.facing != cur.facing) continue;
            boolean sel = g == curGroup;
            addPill(g.label, sel, idle || sel, v -> {
                if (recording || starting || g == curGroup) return;
                closeCamera();
                selectGroup(g);
                tryOpen();
            });
        }
    }

    private void addPill(String label, boolean selected, boolean enabled, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(selected ? label + "x" : label);
        t.setTextColor(selected ? YELLOW : Color.WHITE);
        t.setTextSize(selected ? 15 : 14);
        t.setGravity(Gravity.CENTER);
        t.setBackground(oval(0x66000000, 0, 0));
        t.setAlpha(enabled ? 1f : 0.35f);
        t.setOnClickListener(l);
        t.setRotation(-deviceOrientation);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
        lp.leftMargin = dp(6);
        lp.rightMargin = dp(6);
        pillRow.addView(t, lp);
    }

    private void flashFeedback() {
        flashView.animate().cancel();
        flashView.setAlpha(0.7f);
        flashView.animate().alpha(0f).setDuration(250).start();
    }

    // ================================================================== camera discovery

    private void initCameras() {
        lenses.clear();
        report.setLength(0);
        report.append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(", Android ").append(Build.VERSION.RELEASE).append("\n\n");

        Set<String> listed = new LinkedHashSet<>();
        try {
            listed.addAll(Arrays.asList(manager.getCameraIdList()));
        } catch (Exception e) {
            report.append("Could not list cameras: ").append(e).append('\n');
        }
        for (String id : listed) addLens(id, null, "listed", 0);
        for (int i = 0; i < 128; i++) {
            String id = String.valueOf(i);
            if (listed.contains(id)) continue;
            try {
                manager.getCameraCharacteristics(id);
            } catch (Throwable t) {
                continue;
            }
            addLens(id, null, "hidden", 2);
        }
        for (String id : listed) {
            try {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                if (!isLogical(c)) continue;
                for (String p : c.getPhysicalCameraIds()) {
                    if (listed.contains(p)) continue;
                    addLens(id, p, "via " + id, 1);
                }
            } catch (Throwable t) {
                report.append("id ").append(id).append(": ").append(t).append('\n');
            }
        }
        buildGroups();

        if (lenses.isEmpty()) {
            toast("No cameras found.");
            return;
        }
        Group main = mainGroup(CameraMetadata.LENS_FACING_BACK);
        if (main != null) {
            selectGroup(main);
        } else {
            Lens first = lenses.get(0);
            for (Lens l : lenses) {
                if (l.facing == CameraMetadata.LENS_FACING_BACK) {
                    first = l;
                    break;
                }
            }
            selectLens(first);
        }
    }

    private static boolean isLogical(CameraCharacteristics c) {
        int[] caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        if (caps == null) return false;
        for (int cap : caps) {
            if (cap == CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA) return true;
        }
        return false;
    }

    private void addLens(String openId, String physId, String route, int priority) {
        String shownId = physId != null ? physId : openId;
        try {
            CameraCharacteristics c = manager.getCameraCharacteristics(shownId);
            Lens l = new Lens();
            l.openId = openId;
            l.physId = physId;
            l.route = route;
            l.priority = priority;
            l.chars = c;
            l.openChars = physId != null ? manager.getCameraCharacteristics(openId) : c;
            l.logical = physId == null && isLogical(c);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            l.facing = facing == null ? CameraMetadata.LENS_FACING_EXTERNAL : facing;
            String side = l.facing == CameraMetadata.LENS_FACING_BACK ? "Back"
                    : l.facing == CameraMetadata.LENS_FACING_FRONT ? "Front" : "Ext";

            float[] focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            SizeF sensor = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if (focal != null && focal.length > 0 && sensor != null) {
                double diag = Math.hypot(sensor.getWidth(), sensor.getHeight());
                if (diag > 0) l.equiv = (float) (focal[0] * 43.27 / diag);
            }
            String kind = l.equiv <= 0 ? "" : l.equiv < 20 ? "ultrawide" : l.equiv < 40 ? "wide" : "tele";
            String mm = l.equiv > 0 ? Math.round(l.equiv) + "mm" : "?mm";
            l.label = l.logical
                    ? side + " multi-camera (auto switch)  [id " + openId + "]"
                    : side + " " + mm + " " + kind + "  [id " + shownId + ", " + route + "]";
            lenses.add(l);

            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size max = null;
            if (map != null) {
                Size[] all = map.getOutputSizes(MediaRecorder.class);
                if (all != null) for (Size s : all) if (max == null || area(s) > area(max)) max = s;
            }
            report.append("id ").append(shownId).append(" (").append(route).append(") ")
                    .append(side).append(' ').append(mm).append(' ').append(kind)
                    .append(l.logical ? " LOGICAL phys=" + c.getPhysicalCameraIds() : "")
                    .append("\n  zoom=").append(c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE))
                    .append(" maxVideo=").append(max)
                    .append("\n  eis=").append(Arrays.toString(c.get(
                            CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)))
                    .append(" distortion=").append(Arrays.toString(c.get(
                            CameraCharacteristics.DISTORTION_CORRECTION_AVAILABLE_MODES)))
                    .append("\n\n");
        } catch (Throwable t) {
            report.append("id ").append(shownId).append(" (").append(route)
                    .append(") unreadable: ").append(t).append("\n\n");
        }
    }

    /** Groups the routes by physical lens and labels each lens like 0.6 / 1 / 5. */
    private void buildGroups() {
        groups.clear();
        Map<String, Group> byKey = new LinkedHashMap<>();
        for (Lens l : lenses) {
            if (l.logical) continue;
            String key = l.facing + "_" + (l.equiv > 0 ? String.valueOf(Math.round(l.equiv))
                    : "id" + (l.physId != null ? l.physId : l.openId));
            Group g = byKey.get(key);
            if (g == null) {
                g = new Group();
                g.facing = l.facing;
                g.equiv = l.equiv;
                byKey.put(key, g);
            }
            g.routes.add(l);
        }
        for (Group g : byKey.values()) {
            g.routes.sort((a, b) -> Integer.compare(a.priority, b.priority));
            groups.add(g);
        }
        groups.sort((a, b) -> a.facing != b.facing ? Integer.compare(a.facing, b.facing)
                : Float.compare(a.equiv, b.equiv));
        for (Group g : groups) {
            Group main = mainGroup(g.facing);
            g.label = main != null && main.equiv > 0 && g.equiv > 0
                    ? ratioLabel(g.equiv / main.equiv) : "1";
        }
    }

    /** The lens closest to a normal 24mm view, for the given side. */
    private Group mainGroup(int facing) {
        Group best = null;
        for (Group g : groups) {
            if (g.facing != facing) continue;
            if (best == null) {
                best = g;
                continue;
            }
            float sg = g.equiv >= 18 ? Math.abs(g.equiv - 24) : 1000 + Math.abs(g.equiv - 24);
            float sb = best.equiv >= 18 ? Math.abs(best.equiv - 24) : 1000 + Math.abs(best.equiv - 24);
            if (sg < sb) best = g;
        }
        return best;
    }

    private static long area(Size s) {
        return (long) s.getWidth() * s.getHeight();
    }

    private void selectGroup(Group g) {
        curGroup = g;
        g.idx = g.good >= 0 ? g.good : 0;
        applyLens(g.routes.get(g.idx));
    }

    /** Selects a specific route (from the All cameras list). */
    private void selectLens(Lens l) {
        curGroup = null;
        for (Group g : groups) {
            int i = g.routes.indexOf(l);
            if (i >= 0) {
                curGroup = g;
                g.idx = i;
            }
        }
        applyLens(l);
    }

    private void applyLens(Lens l) {
        cur = l;

        List<Size> found = new ArrayList<>();
        StreamConfigurationMap map = l.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        Size[] all = map == null ? null : map.getOutputSizes(MediaRecorder.class);
        if (all != null) {
            for (Size s : all) {
                float r = (float) s.getWidth() / s.getHeight();
                boolean ratioOk = Math.abs(r - 16f / 9f) < 0.02f || Math.abs(r - 4f / 3f) < 0.02f;
                if (ratioOk && s.getWidth() <= 3840 && s.getHeight() <= 2160 && s.getHeight() >= 720) {
                    found.add(s);
                }
            }
            if (found.isEmpty()) {
                for (Size s : all) if (s.getWidth() <= 3840 && s.getWidth() > s.getHeight()) found.add(s);
            }
        }
        found.sort((a, b) -> Long.compare(area(b), area(a)));
        sizes = found;
        if (!sizes.contains(videoSize)) {
            Size fullHd = new Size(1920, 1080);
            if (sizes.contains(fullHd)) videoSize = fullHd;
            else if (!sizes.isEmpty()) videoSize = sizes.get(0);
        }

        fpsOptions = new ArrayList<>();
        Range<Integer>[] ranges = l.chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
        if (ranges != null) {
            for (int f : new int[]{24, 25, 30, 60}) {
                for (Range<Integer> r : ranges) {
                    if (r.getUpper() == f) {
                        fpsOptions.add(f);
                        break;
                    }
                }
            }
        }
        if (fpsOptions.isEmpty()) fpsOptions.add(30);
        if (!fpsOptions.contains(fps)) fps = fpsOptions.contains(30) ? 30 : fpsOptions.get(0);

        zoomSteps = new ArrayList<>();
        Range<Float> zr = l.logical ? l.chars.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) : null;
        if (zr != null) {
            if (zr.getLower() < 0.99f) zoomSteps.add(zr.getLower());
            zoomSteps.add(1f);
            for (float z : new float[]{2f, 5f}) if (z <= zr.getUpper()) zoomSteps.add(z);
        }
        zoom = 1f;

        evRange = l.openChars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
        evStep = l.openChars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP);
        ev = 0;
        evRow.setVisibility(View.GONE);
        refreshLabels();
    }

    /** Called when a lens route will not open or shows no picture: tries the next route. */
    private void onLensFailed(String why) {
        closeCamera();
        if (curGroup != null && curGroup.idx + 1 < curGroup.routes.size()) {
            curGroup.idx++;
            applyLens(curGroup.routes.get(curGroup.idx));
            tryOpen();
            return;
        }
        toast("This lens could not be opened (" + why + "). Try another one.");
    }

    // ================================================================== menus

    private void showMenu() {
        if (recording || starting) return;
        String[] items = {
                "Lens correction: " + (lensFix ? "On" : "Off (widest, curved edges)"),
                "All cameras…",
                "Camera info"};
        dialog().setItems(items, (d, which) -> {
            if (which == 0) {
                lensFix = !lensFix;
                pushRequest();
                toast(lensFix ? "Lens correction on" : "Lens correction off");
            } else if (which == 1) {
                pickAnyLens();
            } else {
                showInfo();
            }
        }).show();
    }

    private void pickAnyLens() {
        if (lenses.isEmpty() || opening) return;
        String[] items = new String[lenses.size()];
        for (int i = 0; i < items.length; i++) items[i] = lenses.get(i).label;
        dialog().setTitle("All cameras").setItems(items, (d, which) -> {
            closeCamera();
            selectLens(lenses.get(which));
            tryOpen();
        }).show();
    }

    private void pickSize() {
        if (sizes.isEmpty() || recording || starting) return;
        String[] items = new String[sizes.size()];
        for (int i = 0; i < items.length; i++) {
            Size s = sizes.get(i);
            boolean wide = Math.abs((float) s.getWidth() / s.getHeight() - 16f / 9f) < 0.02f;
            items[i] = s.getWidth() + " x " + s.getHeight() + (wide ? "   16:9" : "   4:3 full sensor");
        }
        dialog().setTitle("Video size").setItems(items, (d, which) -> {
            videoSize = sizes.get(which);
            refreshLabels();
            restartPreview();
        }).show();
    }

    private void pickFps() {
        if (recording || starting) return;
        String[] items = new String[fpsOptions.size()];
        for (int i = 0; i < items.length; i++) items[i] = fpsOptions.get(i) + " fps";
        dialog().setTitle("Frame rate").setItems(items, (d, which) -> {
            fps = fpsOptions.get(which);
            refreshLabels();
            restartPreview();
        }).show();
    }

    private void flipCamera() {
        if (recording || starting || cur == null) return;
        int other = cur.facing == CameraMetadata.LENS_FACING_BACK
                ? CameraMetadata.LENS_FACING_FRONT : CameraMetadata.LENS_FACING_BACK;
        Group g = mainGroup(other);
        if (g != null) {
            closeCamera();
            selectGroup(g);
            tryOpen();
            return;
        }
        for (Lens l : lenses) {
            if (l.facing == other) {
                closeCamera();
                selectLens(l);
                tryOpen();
                return;
            }
        }
        toast("No camera on the other side.");
    }

    private void showInfo() {
        final String text = report.toString();
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(11);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(16), dp(12), dp(16), dp(12));
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        dialog().setTitle("Cameras found").setView(sv)
                .setPositiveButton("Copy", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("cameras", text));
                    toast("Copied.");
                })
                .setNegativeButton("Close", null).show();
    }

    // ================================================================== camera open / close

    private void tryOpen() {
        if (!resumed || cur == null || device != null || opening) return;
        if (!texture.isAvailable()) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        final Lens target = cur;
        opening = true;
        try {
            manager.openCamera(target.openId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    opening = false;
                    if (!resumed || cur != target) {
                        camera.close();
                        tryOpen();
                        return;
                    }
                    device = camera;
                    restartPreview();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    opening = false;
                    camera.close();
                    if (device == camera) {
                        device = null;
                        session = null;
                    }
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    opening = false;
                    camera.close();
                    if (device == camera) {
                        device = null;
                        session = null;
                    }
                    if (cur == target && !recording) onLensFailed("error " + error);
                }
            }, ui);
        } catch (Throwable t) {
            opening = false;
            onLensFailed(String.valueOf(t.getMessage()));
        }
    }

    private void closeCamera() {
        pendingStart = false;
        session = null;
        request = null;
        if (device != null) {
            try {
                device.close();
            } catch (Throwable ignored) {
            }
            device = null;
        }
        if (jpegReader != null) {
            jpegReader.close();
            jpegReader = null;
        }
    }

    // ================================================================== preview / session

    private String configKey() {
        return cur.openId + "/" + cur.physId + "/" + videoSize + "/" + fps;
    }

    private boolean wantJpeg() {
        return cur != null && !jpegBad.contains(configKey());
    }

    /** Sizes the preview so the whole frame shows under the top bar, then starts. */
    private void restartPreview() {
        if (device == null || !texture.isAvailable() || root.getWidth() == 0) return;
        int cw = root.getWidth();
        int ch = root.getHeight() - dp(72);
        int vw = cw;
        int vh = Math.round(cw * (float) videoSize.getWidth() / videoSize.getHeight());
        if (vh > ch) {
            vh = ch;
            vw = Math.round(ch * (float) videoSize.getHeight() / videoSize.getWidth());
        }
        if (texture.getWidth() == vw && texture.getHeight() == vh) {
            startSession(false, wantJpeg());
            return;
        }
        pendingStart = true;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(vw, vh,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = dp(72);
        frameBox.setLayoutParams(lp);
        ui.postDelayed(() -> {
            if (pendingStart) {
                pendingStart = false;
                startSession(false, wantJpeg());
            }
        }, 600);
    }

    private Size previewSizeFor(Size video) {
        StreamConfigurationMap map = cur.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        Size[] all = map == null ? null : map.getOutputSizes(SurfaceTexture.class);
        if (all == null) return video;
        float want = (float) video.getWidth() / video.getHeight();
        Size best = null;
        for (Size s : all) {
            if (s.getWidth() > 1920 || s.getHeight() > 1440) continue;
            if (Math.abs((float) s.getWidth() / s.getHeight() - want) > 0.02f) continue;
            if (best == null || area(s) > area(best)) best = s;
        }
        return best == null ? video : best;
    }

    private Size jpegSizeFor(Size video) {
        StreamConfigurationMap map = cur.chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        Size[] all = map == null ? null : map.getOutputSizes(ImageFormat.JPEG);
        if (all == null) return video;
        float want = (float) video.getWidth() / video.getHeight();
        Size best = null;
        for (Size s : all) {
            if (s.getWidth() > 4096 || s.getHeight() > 3072) continue;
            if (Math.abs((float) s.getWidth() / s.getHeight() - want) > 0.02f) continue;
            if (best == null || area(s) > area(best)) best = s;
        }
        return best == null ? video : best;
    }

    private void startSession(final boolean forRecording, final boolean withJpeg) {
        final CameraDevice dev = device;
        SurfaceTexture st = texture.getSurfaceTexture();
        if (dev == null || st == null) {
            if (forRecording) abortRecording("Camera is not ready.");
            return;
        }
        ImageReader reader = null;
        try {
            Size p = previewSizeFor(videoSize);
            st.setDefaultBufferSize(p.getWidth(), p.getHeight());
            if (previewSurface == null) previewSurface = new Surface(st);

            final CaptureRequest.Builder b = dev.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            List<Surface> outs = new ArrayList<>();
            outs.add(previewSurface);
            b.addTarget(previewSurface);
            if (forRecording) {
                outs.add(recorder.getSurface());
                b.addTarget(recorder.getSurface());
            }
            if (withJpeg) {
                Size js = jpegSizeFor(videoSize);
                reader = ImageReader.newInstance(js.getWidth(), js.getHeight(), ImageFormat.JPEG, 2);
                reader.setOnImageAvailableListener(this::onJpeg, ui);
                outs.add(reader.getSurface());
            }
            List<OutputConfiguration> outputs = new ArrayList<>();
            for (Surface s : outs) {
                OutputConfiguration oc = new OutputConfiguration(s);
                if (cur.physId != null) oc.setPhysicalCameraId(cur.physId);
                outputs.add(oc);
            }
            applySettings(b);

            final ImageReader fr = reader;
            final String key = configKey();
            CameraCaptureSession.StateCallback cb = new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession s) {
                    if (device != dev) {
                        if (fr != null) fr.close();
                        return;
                    }
                    ImageReader old = jpegReader;
                    jpegReader = fr;
                    if (old != null && old != fr) old.close();
                    session = s;
                    request = b;
                    try {
                        s.setRepeatingRequest(b.build(), null, ui);
                        if (forRecording) {
                            onRecordingSessionReady();
                        } else {
                            watchForPicture(s);
                        }
                    } catch (Throwable t) {
                        if (forRecording) abortRecording("Could not start: " + t.getMessage());
                        else toast("Preview failed: " + t.getMessage());
                    }
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession s) {
                    if (fr != null) fr.close();
                    if (device != dev) return;
                    if (withJpeg) {
                        // Photo stream not supported alongside video here: run without it.
                        jpegBad.add(key);
                        startSession(forRecording, false);
                    } else if (forRecording) {
                        abortRecording("The phone refused this size / frame rate. Try another.");
                    } else {
                        onLensFailed("refused this size / frame rate");
                    }
                }
            };
            dev.createCaptureSession(new SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR, outputs, getMainExecutor(), cb));
        } catch (Throwable t) {
            if (reader != null) reader.close();
            if (forRecording) abortRecording("Could not start: " + t.getMessage());
            else toast("Preview failed: " + t.getMessage());
        }
    }

    /** If a route opens but never shows a picture, move on to the next route. */
    private void watchForPicture(final CameraCaptureSession s) {
        frameSeen = false;
        if (curGroup == null || curGroup.good == curGroup.idx
                || curGroup.idx + 1 >= curGroup.routes.size()) return;
        ui.postDelayed(() -> {
            if (session == s && !frameSeen && !recording && !starting) onLensFailed("no picture");
        }, 3000);
    }

    private static boolean has(int[] modes, int mode) {
        if (modes == null) return false;
        for (int m : modes) if (m == mode) return true;
        return false;
    }

    private void applySettings(CaptureRequest.Builder b) {
        CameraCharacteristics c = cur.chars;

        // No electronic stabilisation: no crop.
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF);
        // Optical stabilisation off too (the setup that gave the widest ultrawide).
        if (has(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION),
                CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF)) {
            b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF);
        }

        int[] distModes = c.get(CameraCharacteristics.DISTORTION_CORRECTION_AVAILABLE_MODES);
        int wantDist = lensFix ? CameraMetadata.DISTORTION_CORRECTION_MODE_FAST
                : CameraMetadata.DISTORTION_CORRECTION_MODE_OFF;
        if (has(distModes, wantDist)) b.set(CaptureRequest.DISTORTION_CORRECTION_MODE, wantDist);

        Range<Integer>[] ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
        Range<Integer> pick = null;
        if (ranges != null) {
            for (Range<Integer> r : ranges) {
                if (r.getUpper() != fps) continue;
                if (pick == null || r.getLower() > pick.getLower()) pick = r;
            }
        }
        if (pick != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, pick);

        if (cur.logical && zoomSteps.size() > 1) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom);

        if (evRange != null && evRange.getUpper() > evRange.getLower()) {
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev);
        }

        if (flashAvailable()) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
            b.set(CaptureRequest.FLASH_MODE, torch ? CameraMetadata.FLASH_MODE_TORCH
                    : CameraMetadata.FLASH_MODE_OFF);
        }
    }

    private void pushRequest() {
        if (session == null || request == null || device == null) return;
        try {
            applySettings(request);
            session.setRepeatingRequest(request.build(), null, ui);
        } catch (Throwable t) {
            toast("Could not apply: " + t.getMessage());
        }
    }

    // ================================================================== snapshot

    private int captureRotation() {
        Integer so = cur.chars.get(CameraCharacteristics.SENSOR_ORIENTATION);
        int sensor = so == null ? 90 : so;
        return cur.facing == CameraMetadata.LENS_FACING_FRONT
                ? (sensor - deviceOrientation + 360) % 360
                : (sensor + deviceOrientation) % 360;
    }

    private void takeSnapshot() {
        if (device == null || session == null || starting || cur == null) return;
        flashFeedback();
        if (jpegReader != null && !recording) {
            try {
                CaptureRequest.Builder b = device.createCaptureRequest(recording
                        ? CameraDevice.TEMPLATE_VIDEO_SNAPSHOT : CameraDevice.TEMPLATE_STILL_CAPTURE);
                b.addTarget(previewSurface);
                if (recording && recorder != null) b.addTarget(recorder.getSurface());
                b.addTarget(jpegReader.getSurface());
                applySettings(b);
                b.set(CaptureRequest.JPEG_ORIENTATION, captureRotation());
                b.set(CaptureRequest.JPEG_QUALITY, (byte) 95);
                session.capture(b.build(), null, ui);
                return;
            } catch (Throwable ignored) {
                // fall back to grabbing the preview frame
            }
        }
        snapshotFromPreview();
    }

    private void onJpeg(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            ByteBuffer buf = img.getPlanes()[0].getBuffer();
            final byte[] data = new byte[buf.remaining()];
            buf.get(data);
            io.execute(() -> savePhoto(data));
        } catch (Throwable t) {
            toast("Photo failed: " + t.getMessage());
        } finally {
            if (img != null) img.close();
        }
    }

    /** Fallback when the phone will not run a photo stream next to the video. */
    private void snapshotFromPreview() {
        final Bitmap bm = texture.getBitmap();
        if (bm == null) return;
        final int rot = deviceOrientation;
        io.execute(() -> {
            Bitmap out = bm;
            if (rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                out = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            out.compress(Bitmap.CompressFormat.JPEG, 95, bos);
            savePhoto(bos.toByteArray());
        });
    }

    private void savePhoto(byte[] data) {
        try {
            String name = "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date()) + ".jpg";
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NoStabCam");
            v.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IllegalStateException("no storage");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new IllegalStateException("no storage");
                os.write(data);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
            ui.post(() -> setLast(uri, "image/jpeg"));
        } catch (Throwable t) {
            ui.post(() -> toast("Photo not saved: " + t.getMessage()));
        }
    }

    // ================================================================== gallery thumbnail

    private void setLast(Uri uri, String mime) {
        lastUri = uri;
        lastMime = mime;
        getSharedPreferences("app", MODE_PRIVATE).edit()
                .putString("lastUri", uri.toString()).putString("lastMime", mime).apply();
        loadThumb();
    }

    private void loadThumb() {
        final Uri uri = lastUri;
        if (uri == null) return;
        io.execute(() -> {
            Bitmap b = null;
            try {
                b = getContentResolver().loadThumbnail(uri, new Size(200, 200), null);
            } catch (Throwable ignored) {
            }
            final Bitmap fb = b;
            ui.post(() -> {
                if (uri.equals(lastUri)) thumb.setImageBitmap(fb);
            });
        });
    }

    private void openLast() {
        if (lastUri == null || recording || starting) return;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(lastUri, lastMime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Throwable t) {
            toast("No app to open it. Find it in Gallery under NoStabCam.");
        }
    }

    // ================================================================== recording

    private void startRecording() {
        if (device == null || session == null || recording || starting) return;
        starting = true;
        refreshLabels();
        try {
            String name = "VID_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
            ContentValues v = new ContentValues();
            v.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            v.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/NoStabCam");
            v.put(MediaStore.Video.Media.IS_PENDING, 1);
            outUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
            if (outUri == null) throw new IllegalStateException("no storage");
            outFd = getContentResolver().openFileDescriptor(outUri, "rw");
            if (outFd == null) throw new IllegalStateException("no storage");

            boolean audio = checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED;
            int w = videoSize.getWidth();
            int h = videoSize.getHeight();
            long bitrate = Math.min(100_000_000L, Math.max(8_000_000L, (long) (w * h * fps * 0.2)));

            recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            if (audio) recorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setOutputFile(outFd.getFileDescriptor());
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            recorder.setVideoSize(w, h);
            recorder.setVideoFrameRate(fps);
            recorder.setVideoEncodingBitRate((int) bitrate);
            if (audio) {
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                recorder.setAudioEncodingBitRate(192_000);
                recorder.setAudioSamplingRate(48_000);
                recorder.setAudioChannels(2);
            }
            recorder.setOrientationHint(captureRotation());
            recorder.prepare();
            // No photo stream while recording: on this phone it freezes the video after ~1s.
            startSession(true, false);
        } catch (Throwable t) {
            abortRecording("Could not start recording: " + t.getMessage());
        }
    }

    private void onRecordingSessionReady() {
        recorder.start();
        starting = false;
        recording = true;
        recStart = SystemClock.elapsedRealtime();
        setRecButton(true);
        refreshLabels();
        ui.post(tick);
        scheduleDark();
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!recording) {
                topTimer.setText("");
                darkTimer.setText("");
                return;
            }
            long s = (SystemClock.elapsedRealtime() - recStart) / 1000;
            String t = s >= 3600
                    ? String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                    : String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
            topTimer.setText(t);
            darkTimer.setText("● " + t);
            ui.postDelayed(this, 500);
        }
    };

    private void abortRecording(String message) {
        starting = false;
        recording = false;
        releaseRecorder(false);
        setRecButton(false);
        refreshLabels();
        toast(message);
        if (resumed && device != null) startSession(false, wantJpeg());
    }

    private void stopRecording(boolean backToPreview) {
        boolean wasRecording = recording;
        recording = false;
        starting = false;
        ui.removeCallbacks(goDark);
        setDark(false);
        try {
            if (session != null) {
                session.stopRepeating();
                session.abortCaptures();
            }
        } catch (Throwable ignored) {
        }
        boolean ok = wasRecording;
        if (wasRecording && recorder != null) {
            try {
                recorder.stop();
            } catch (RuntimeException e) {
                ok = false;
            }
        }
        Uri saved = ok ? outUri : null;
        releaseRecorder(ok);
        setRecButton(false);
        refreshLabels();
        if (saved != null) setLast(saved, "video/mp4");
        else toast("Recording was too short to save.");
        if (backToPreview && device != null) startSession(false, wantJpeg());
    }

    private void releaseRecorder(boolean keepFile) {
        if (recorder != null) {
            try {
                recorder.reset();
                recorder.release();
            } catch (Throwable ignored) {
            }
            recorder = null;
        }
        if (outFd != null) {
            try {
                outFd.close();
            } catch (Throwable ignored) {
            }
            outFd = null;
        }
        if (outUri != null) {
            try {
                if (keepFile) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Video.Media.IS_PENDING, 0);
                    getContentResolver().update(outUri, v, null, null);
                } else {
                    getContentResolver().delete(outUri, null, null);
                }
            } catch (Throwable ignored) {
            }
            outUri = null;
        }
    }

    // ================================================================== TextureView callbacks

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
        tryOpen();
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
        if (pendingStart) {
            pendingStart = false;
            startSession(false, wantJpeg());
        }
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        closeCamera();
        if (previewSurface != null) {
            previewSurface.release();
            previewSurface = null;
        }
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture st) {
        if (!frameSeen) {
            frameSeen = true;
            if (curGroup != null) curGroup.good = curGroup.idx;
        }
    }

    // ================================================================== viewfinder corners

    private static class Corners extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float len;

        Corners(Context c, float density) {
            super(c);
            p.setColor(0x99FFFFFF);
            p.setStrokeWidth(1.5f * density);
            p.setStyle(Paint.Style.STROKE);
            len = 22 * density;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), s = p.getStrokeWidth() / 2;
            c.drawLine(s, s, len, s, p);
            c.drawLine(s, s, s, len, p);
            c.drawLine(w - len, s, w - s, s, p);
            c.drawLine(w - s, s, w - s, len, p);
            c.drawLine(s, h - s, len, h - s, p);
            c.drawLine(s, h - len, s, h - s, p);
            c.drawLine(w - len, h - s, w - s, h - s, p);
            c.drawLine(w - s, h - len, w - s, h - s, p);
        }
    }
}
